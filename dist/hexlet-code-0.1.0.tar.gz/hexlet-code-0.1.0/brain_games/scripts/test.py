from random import randint, choice


def set_prog():
    start = randint(1, 10)
    stop = randint(40, 50)
    step = randint(2, 5)
    prog = list(range(start, stop, step))
    missing_number = choice(prog)

    for i, number in enumerate(prog):
        if number == missing_number:
            prog[i] = '..'
    return prog

